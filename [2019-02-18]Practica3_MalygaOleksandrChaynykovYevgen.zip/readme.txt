﻿Yevgen Chaynykov y Oleksandr Malyga
Acceso a datos, Desarrollo de Aplicaciones Multiplataforma, 18/02/2019


Debido a como se han diseñado las clases desde un principio, no hemos podido implementar los métodos de consulta (enunciados 8.1, 8.2, 8.3) 
utilizando las clases proporcionadas por NeoDatis (IQuery, Where, etc), y hemos tenido que recurrir a implementaciones propias.
El enunciado 8.4 si que lo hemos podido hacer, por lo menos parcialmente, usando las clases de NeoDatis.