package entities;

public enum PanelType {
	PHOTOVOLTAIC, THERMODYNAMIC
}
